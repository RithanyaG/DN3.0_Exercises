import java.util.*;
import java.util.Comparator;

public class Book {
    int bookId;
    String title;
    String author;

    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return "Book ID: " + bookId + ", Title: " + title + ", Author: " + author;
    }
    public static Book linearSearch(Book[] products, String productName) {
        for (Book product : products) {
            if (product.title.equalsIgnoreCase(productName)) {
                return product;
            }
        }
        return null; 
    }
    public static Book binarySearch(Book[] products, String productName) {
        int left = 0;
        int right = products.length - 1;
    
        while (left <= right) {
            int mid = (left + right) / 2;
            int cmp = products[mid].title.compareToIgnoreCase(productName);
    
            if (cmp == 0) {
                return products[mid]; 
            } else if (cmp < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null; 
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
    Book[] products = {
        new Book(1, "HarryPotter", "JKRowling"),
        new Book(2, "Revolution2020", "Chetan"),
        new Book(3, "Half", "Bhagat"),
        new Book(4, "unknown", "Author")
    };

    // For binary search, the array should be sorted by product name
    Arrays.sort(products, Comparator.comparing(p -> p.title));
    System.out.println("Enter book name for search: ");
    String searchName = sc.nextLine();
    Book result = linearSearch(products, searchName);
    if(result != null)
        System.out.println("Linear Search Result: " +  result );
    else
        System.out.println("Linear Search Result: Book not found");
    result = binarySearch(products, searchName);
    if(result != null)
        System.out.println("Binary Search Result: " +  result );
    else
        System.out.println("Binary Search Result: Book not found");
}

}
