import java.util.ArrayList;
import java.util.Collections;

class Forecast {
    
    ArrayList<Integer> growth = new ArrayList<>();
    
    int[] arr = new int[]{1, 2, 3, 4, 8};

    
    public void finance(int p1, int p2) {
        
        if (p2 == arr.length) {
            return;
        }

        
        growth.add(arr[p2] - arr[p1]);


        finance(p1 + 1, p2 + 1);
    }

    public static void main(String[] args) {
        Forecast forecast = new Forecast();
        forecast.finance(0, 1);

        int last = forecast.arr.length - 1;
        int max = Collections.max(forecast.growth);
        int min = Collections.min(forecast.growth);
        int sum = 0;

        for (int value : forecast.arr) {
            sum += value;
        }
        int avg = sum / forecast.arr.length;

        System.out.println("Financial Growth Analysis:");
        System.out.println("---------------------------");
        System.out.println("Minimum growth  : " + (last + min));
        System.out.println("Average growth  : " + (last + avg));
        System.out.println("Maximum growth  : " + (last + max));
    }
}
