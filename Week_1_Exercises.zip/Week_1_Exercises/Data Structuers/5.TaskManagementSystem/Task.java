import java.util.*;

class Task {
    private HashMap<Integer, ArrayList<String>> taskMap = new HashMap<>();
    private LinkedList<Integer> taskIds = new LinkedList<>();

    public void addTask(int taskId) {
        taskIds.add(taskId);
        Scanner scanner = new Scanner(System.in);

        ArrayList<String> taskDetails = new ArrayList<>();
        System.out.println("Enter Task Name: ");
        String taskName = scanner.nextLine();
        taskDetails.add(taskName);

        System.out.println("Enter Task Status: ");
        String status = scanner.nextLine();
        taskDetails.add(status);

        taskMap.put(taskId, taskDetails);
    }

    public int searchTask(int taskId) {
        return taskIds.indexOf(taskId);
    }

    public void removeTask(int taskId) {
        taskIds.remove(Integer.valueOf(taskId));
        taskMap.remove(taskId);
    }

    public void traverse() {
        for (int taskId : taskIds) {
            System.out.println("Task ID: " + taskId);
            ArrayList<String> taskDetails = taskMap.get(taskId);
            if (taskDetails != null) {
                System.out.println("Task Name: " + taskDetails.get(0));
                System.out.println("Task Status: " + taskDetails.get(1));
                System.out.println("------------------------");
            }
        }
    }

    public static void main(String[] args) {
        Task taskManager = new Task();
        taskManager.addTask(123);
        int index = taskManager.searchTask(123);
        taskManager.addTask(101);
        taskManager.removeTask(123);
        taskManager.traverse();
    }
}
