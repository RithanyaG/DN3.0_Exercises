//target interface
public interface PaymentProcessor{
    void processPayment(double amount);
}
//2 adaptee classes gateway1 and gateway2 with their own methods
class gateway1{
    public void makePayments(double amount){
        System.out.println("Payment of Rs." + amount + " processed through gateway1.");
    }
}
class gateway2{
    public void sendPayments(double amount){
        System.out.println("Payment of Rs." + amount + " processed through gateway2.");
    }
}
//adapter classes for adaptee classes
class gateway1Adapter implements PaymentProcessor{
    private gateway1 obj1;

    public gateway1Adapter(gateway1 obj1){
        this.obj1=obj1;
    }

    public void processPayment(double amount){
        obj1.makePayments(amount);
    }
}
class gateway2Adapter implements PaymentProcessor{
    private gateway2 obj2;

    public gateway2Adapter(gateway2 obj2){
        this.obj2=obj2;
    }

    public void processPayment(double amount){
        obj2.sendPayments(amount);
    }
}
//client class to interact with the adapter
class paymentTest{
    public static void main(String args[]){
        PaymentProcessor g1=new gateway1Adapter(new gateway1());
        g1.processPayment(100.0);

        PaymentProcessor g2=new gateway2Adapter(new gateway2());
        g2.processPayment(200.0);        
    }
}