import java.util.*;
//subject interface
public interface Stock {
    void registerObserver(Observer observer);
    void removeObserver(Observer observer);
    void notifyObservers();
}
//stockmarket class that implement stock and maintains a list of observers
class StockMarket implements Stock {
    private List<Observer> observers;
    private String stockName;
    private double stockPrice;

    public StockMarket(String stockName, double stockPrice) {
        this.stockName = stockName;
        this.stockPrice = stockPrice;
        this.observers = new ArrayList<>();
    }
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }
    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(stockName, stockPrice);
        }
    }

    public void setStockPrice(double stockPrice) {
        this.stockPrice = stockPrice;
        notifyObservers();
    }
}
// Observer interface
interface Observer {
    void update(String stockName, double stockPrice);
}
//classes that implement observer
class MobileApp implements Observer {
    private String appName;

    public MobileApp(String appName) {
        this.appName = appName;
    }
    public void update(String stockName, double stockPrice) {
        System.out.println(appName + " received an update: " + stockName + " is now $" + stockPrice);
    }
}
class WebApp implements Observer {
    private String appName;

    public WebApp(String appName) {
        this.appName = appName;
    }
    public void update(String stockName, double stockPrice) {
        System.out.println(appName + " received an update: " + stockName + " is now $" + stockPrice);
    }
}
//test class
class ObserverPatternExample {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket("AAPL", 150.00);

        Observer mobileApp1 = new MobileApp("MobileApp1");
        Observer mobileApp2 = new MobileApp("MobileApp2");
        Observer webApp1 = new WebApp("WebApp1");

        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(mobileApp2);
        stockMarket.registerObserver(webApp1);

        stockMarket.setStockPrice(155.00); // Notify all observers
        System.out.println();

        stockMarket.removeObserver(mobileApp2);

        stockMarket.setStockPrice(160.00); // Notify remaining observers
    }
}
